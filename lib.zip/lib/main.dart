import 'package:flutter/material.dart';
import 'package:habitualize/page/Rootpage/rootpage.dart';
import 'package:habitualize/page/homepage/HomeScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/', // ✅ Define the initial route
      routes: {
      //  '/': (context) => RootPage(),
        '/home': (context) => HabitualizeHome(), // ✅ Define the home route
      },
    );
  }
}
