import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

class RoutineSection extends StatefulWidget {
  final String title;
  final String routineType;
  final List<String> defaultHabits;

  const RoutineSection({super.key, required this.title, required this.routineType, required this.defaultHabits});

  @override
  _RoutineSectionState createState() => _RoutineSectionState();
}

class _RoutineSectionState extends State<RoutineSection> {
  Map<String, bool> habitsChecked = {};
  List<String> habits = [];
  TextEditingController habitController = TextEditingController();
  bool isExpanded = false;

 @override
void initState() {
  super.initState();
  habits = [...widget.defaultHabits]; // Copy default habits
  for (var habit in habits) {
    habitsChecked.putIfAbsent(habit, () => false);
  }
}

  double get completionRate {
    if (habits.isEmpty) return 0.0;
    int completed = habitsChecked.values.where((checked) => checked).length;
    return completed / habits.length;
  }

  void addHabit() {
    if (habitController.text.isNotEmpty) {
      setState(() {
        habits.add(habitController.text);
        habitsChecked[habitController.text] = false;
        habitController.clear();
      });
    }
  }

  void removeHabit(String habit) {
    setState(() {
      habits.remove(habit);
      habitsChecked.remove(habit);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade300, Colors.blue.shade600],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 5, offset: Offset(0, 3)),
        ],
      ),
      child: SingleChildScrollView(
        child: Column(
          children: [
            ListTile(
              title: Text(
                widget.title,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularPercentIndicator(
                    radius: 20.0,
                    lineWidth: 4.0,
                    percent: completionRate,
                    center: Text(
                      "${(completionRate * 100).toInt()}%",
                      style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                    progressColor: Colors.white,
                    backgroundColor: Colors.white24,
                  ),
                  SizedBox(width: 10),
                  IconButton(
                    icon: Icon(isExpanded ? Icons.expand_less : Icons.expand_more, color: Colors.white),
                    onPressed: () {
                      setState(() {
                        isExpanded = !isExpanded;
                      });
                    },
                  ),
                ],
              ),
            ),
            if (isExpanded)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                child: Column(
                  children: [
                    TextField(
                      controller: habitController,
                      decoration: InputDecoration(
                        hintText: "Enter new habit",
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: addHabit,
                      child: Text("Add Habit"),
                    ),
                    SizedBox(height: 10),
                    Column(
                      children: habits.map((habit) {
                        return Card(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: ListTile(
                            leading: Checkbox(
                              value: habitsChecked[habit] ?? false,
                              onChanged: (bool? value) {
                                setState(() {
                                  habitsChecked[habit] = value ?? false;
                                });
                              },
                            ),
                            title: Text(
                              habit,
                              style: TextStyle(
                                fontSize: 16,
                                decoration: (habitsChecked[habit] ?? false)
                                    ? TextDecoration.lineThrough
                                    : TextDecoration.none,
                              ),
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () => removeHabit(habit),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
