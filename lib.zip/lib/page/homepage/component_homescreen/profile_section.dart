import 'package:flutter/material.dart';

class ProfileSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.blueAccent),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CircleAvatar(radius: 30, backgroundImage: AssetImage("assets/images/boy_av_2.png")),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Hello, User!", style: TextStyle(fontSize: 18, color: Colors.white)),
              Text("Keep up the great work!", style: TextStyle(fontSize: 14, color: Colors.white70)),
            ],
          ),
          Icon(Icons.settings, color: Colors.white),
        ],
      ),
    );
  }
}
