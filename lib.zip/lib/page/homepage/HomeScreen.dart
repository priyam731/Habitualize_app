
import 'package:flutter/material.dart';
import 'package:habitualize/page/homepage/component_homescreen/habit_routine.dart';
import 'package:habitualize/page/homepage/component_homescreen/streak_section.dart';
import 'package:habitualize/widgets/my_calendar.dart';

List<String> morningHabits = ["Drink Water", "Stretch", "Meditate"];
List<String> workdayHabits = ["Plan Tasks", "Take Breaks", "Check Emails"];
List<String> nightHabits = ["Read a Book", "Reflect on Day", "Prepare for Sleep"];

class HabitualizeHome extends StatefulWidget {
  @override
  _HabitualizeHomeState createState() => _HabitualizeHomeState();
}

class _HabitualizeHomeState extends State<HabitualizeHome> {
  final int streakCount = 7;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Habitualize"),
        actions: [
          StreakSection(
            streakCount: streakCount,
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => MyCalendar(streakCount: streakCount),
              );
            },
          ),
          IconButton(
            icon: CircleAvatar(
              radius: 16,
              backgroundImage: AssetImage("assets/images/boy_av_2.png"),
            ),
            onPressed: () {
              showProfileDialog(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            RoutineSection(
              title: "🌅 Morning Routine",
              defaultHabits: morningHabits,
              routineType: "Morning",
            ),
            RoutineSection(
              title: "🏢 Workday Routine",
              defaultHabits: workdayHabits,
              routineType: "Workday",
            ),
            RoutineSection(
              title: "🌙 Night Routine",
              defaultHabits: nightHabits,
              routineType: "Night",
            ),
          ],
        ),
      ),
    );
  }

  void showProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Profile"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 40,
                backgroundImage: AssetImage("assets/images/boy_av_2.png"),
              ),
              SizedBox(height: 10),
              Text("Hello, User!", style: TextStyle(fontSize: 18)),
              Text("Keep up the great work!", style: TextStyle(fontSize: 14, color: Colors.grey)),
            ],
          ),
          actions: [
            TextButton(
              child: Text("Close"),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        );
      },
    );
  }
}
