import 'package:flutter/material.dart';
import 'package:habitualize/page/homepage/HomeScreen.dart';
import 'package:habitualize/page/auth/LoginPage.dart';

class RootPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Simulate login check (replace with actual logic)
    bool isLoggedIn = false; // Change this to true after successful login

    return isLoggedIn ? HabitualizeHome() : LoginPage();
  }
}
