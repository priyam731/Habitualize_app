
import 'package:flutter/material.dart';

class JournalPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Journal"),
      ),
      body: Center(
        child: Text(
          "Write Your Thoughts",
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
