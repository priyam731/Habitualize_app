
import 'package:flutter/material.dart';

class DiscoverPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Discover"),
      ),
      body: Center(
        child: Text(
          "Discover New Habits",
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
